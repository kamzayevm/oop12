package src.Exeption;

import java.io.Serializable;

public class IsNotSuperviser implements Serializable {
    
    
}