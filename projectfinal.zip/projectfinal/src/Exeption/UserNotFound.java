package src.Exeption;

import java.io.Serializable;

public class UserNotFound implements Serializable {

    
}