package src.Exeption;

import java.io.Serializable;

public class LimitedAccess implements Serializable {

    
}