package src.Researcher;

import java.util.List;

public interface Supervisor {
    int calculateHIndex(List<ResearchPaper> papers);
}
