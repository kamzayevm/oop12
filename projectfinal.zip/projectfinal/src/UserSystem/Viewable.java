package src.UserSystem;

public class Viewable {
    public void showMainMenu() {
        System.out.println("\nWelcome to the university system");
        System.out.println("Menu: choose your option");
        System.out.println("1. Login");
        System.out.println("2. Exit");
    }

    public void showUserMenu() {
        System.out.println("\nMenu: choose your option");
        System.out.println("1. Change password");
        System.out.println("2. Create request");
    }
}
